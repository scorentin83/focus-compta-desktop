let selectedCompany = null;
let selectedBankAccount = null;
let selectedStatementId = 'all';
let selectedTransaction = null;
let searchTimer = null;

const MONTH_LABELS = {
    '01': 'Janvier',
    '02': 'Février',
    '03': 'Mars',
    '04': 'Avril',
    '05': 'Mai',
    '06': 'Juin',
    '07': 'Juillet',
    '08': 'Août',
    '09': 'Septembre',
    '10': 'Octobre',
    '11': 'Novembre',
    '12': 'Décembre'
};

function formatAmount(value) {
    return Number(value || 0).toLocaleString('fr-FR', {
        style: 'currency',
        currency: 'EUR'
    });
}

function getStatusLabel(status) {
    const labels = {
        missing: '❌ Manquant',
        attached: '📎 Pièce jointe',
        verified: '✅ Vérifié',
        review: '⚠️ À vérifier',
        ignored: 'Ignoré'
    };

    return labels[status] || '❌ Manquant';
}

function getFilters() {
    return {
        search: document.getElementById('searchInput')?.value.trim() || '',
        year: document.getElementById('yearFilter')?.value || 'all',
        month: document.getElementById('monthFilter')?.value || 'all',
        status: document.getElementById('statusFilter')?.value || 'all',
        statementId: selectedStatementId || 'all'
    };
}

function resetTransactionDetail() {
    selectedTransaction = null;
    document.getElementById('transactionDetailEmpty').style.display = 'block';
    document.getElementById('transactionDetail').style.display = 'none';
    document.getElementById('receiptPreview').textContent = 'Aucun aperçu sélectionné.';
    document.getElementById('receiptPreview').className = 'receipt-preview muted';
}

async function loadCompanies() {
    const companies = await window.api.getCompanies();
    const list = document.getElementById('companyList');
    list.innerHTML = '';

    companies.forEach(company => {
        const li = document.createElement('li');
        li.textContent = company.name;
        li.className = 'clickable';

        li.addEventListener('click', async () => {
            selectedCompany = company;
            selectedBankAccount = null;
            selectedStatementId = 'all';

            document.getElementById('selectedCompanyTitle').textContent = company.name;
            document.getElementById('bankSection').style.display = 'block';
            document.getElementById('statementSidebar').style.display = 'none';

            document.getElementById('selectedAccountTitle').textContent = 'Sélectionne un compte bancaire';
            document.getElementById('statementSection').style.display = 'none';
            document.getElementById('summaryCards').style.display = 'none';
            document.getElementById('toolsPanel').style.display = 'none';
            document.getElementById('transactionTable').style.display = 'none';

            resetTransactionDetail();
            await loadBankAccounts();
        });

        list.appendChild(li);
    });
}

async function loadBankAccounts() {
    if (!selectedCompany) return;

    const accounts = await window.api.getBankAccounts(selectedCompany.id);
    const list = document.getElementById('bankAccountList');
    list.innerHTML = '';

    accounts.forEach(account => {
        const li = document.createElement('li');

        const title = [
            account.bank_name,
            account.account_name,
            account.iban
        ].filter(Boolean).join(' — ');

        li.textContent = title;
        li.className = 'clickable';

        li.addEventListener('click', async () => {
            selectedBankAccount = account;
            selectedStatementId = 'all';

            document.getElementById('selectedAccountTitle').textContent = title;
            document.getElementById('statementSection').style.display = 'block';
            document.getElementById('summaryCards').style.display = 'grid';
            document.getElementById('toolsPanel').style.display = 'grid';
            document.getElementById('transactionTable').style.display = 'table';
            document.getElementById('statementSidebar').style.display = 'block';

            resetTransactionDetail();
            await refreshAccountView(true);
        });

        list.appendChild(li);
    });
}

async function refreshAccountView(refreshPeriods = false) {
    if (refreshPeriods) {
        await loadAvailablePeriods();
    }

    await loadStatements();
    await loadSummary();
    await loadTransactions();
}

async function loadAvailablePeriods() {
    if (!selectedBankAccount) return;

    const periods = await window.api.getAvailablePeriods(selectedBankAccount.id);
    const yearFilter = document.getElementById('yearFilter');
    const monthFilter = document.getElementById('monthFilter');

    const selectedYear = yearFilter.value || 'all';
    const selectedMonth = monthFilter.value || 'all';

    const years = [...new Set(periods.map(period => period.year).filter(Boolean))];
    const months = [...new Set(periods.map(period => period.month).filter(Boolean))].sort();

    yearFilter.innerHTML = '<option value="all">Toutes</option>';
    years.forEach(year => {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearFilter.appendChild(option);
    });

    monthFilter.innerHTML = '<option value="all">Tous</option>';
    months.forEach(month => {
        const option = document.createElement('option');
        option.value = month;
        option.textContent = MONTH_LABELS[month] || month;
        monthFilter.appendChild(option);
    });

    yearFilter.value = years.includes(selectedYear) ? selectedYear : 'all';
    monthFilter.value = months.includes(selectedMonth) ? selectedMonth : 'all';
}

function groupStatementsByPeriod(statements) {
    const groups = {};

    statements.forEach(statement => {
        const year = statement.statement_year || 'Sans année';
        const month = statement.statement_month || 'Sans mois';
        const key = `${year}-${month}`;

        if (!groups[key]) {
            groups[key] = {
                year,
                month,
                label: statement.statement_year && statement.statement_month
                    ? `${MONTH_LABELS[statement.statement_month] || statement.statement_month} ${statement.statement_year}`
                    : 'Période inconnue',
                statements: []
            };
        }

        groups[key].statements.push(statement);
    });

    return Object.values(groups);
}

async function loadStatements() {
    if (!selectedBankAccount) return;

    const statements = await window.api.getStatements(selectedBankAccount.id);
    const select = document.getElementById('statementSelect');
    const meta = document.getElementById('statementMeta');
    const deleteButton = document.getElementById('deleteSelectedStatement');
    const openButton = document.getElementById('openSelectedStatement');

    select.innerHTML = '<option value="all">Tous les relevés</option>';

    if (statements.length === 0) {
        meta.textContent = 'Aucun relevé importé.';
        deleteButton.disabled = true;
        openButton.disabled = true;
        selectedStatementId = 'all';
        return;
    }

    const groups = groupStatementsByPeriod(statements);

    groups.forEach(group => {
        const optgroup = document.createElement('optgroup');
        optgroup.label = group.label;

        group.statements.forEach(statement => {
            const option = document.createElement('option');
            option.value = String(statement.id);
            option.textContent = `${statement.filename} (${statement.transactions_count || 0} op.)`;
            option.dataset.filename = statement.filename;
            option.dataset.filepath = statement.filepath;
            option.dataset.transactionsCount = statement.transactions_count || 0;
            option.dataset.receiptsCount = statement.receipts_count || 0;
            optgroup.appendChild(option);
        });

        select.appendChild(optgroup);
    });

    const exists = statements.some(statement => String(statement.id) === String(selectedStatementId));
    if (!exists) selectedStatementId = 'all';

    select.value = selectedStatementId;
    updateStatementMeta();
}

function getSelectedStatementOption() {
    const select = document.getElementById('statementSelect');
    return select.options[select.selectedIndex] || null;
}

function updateStatementMeta() {
    const option = getSelectedStatementOption();
    const meta = document.getElementById('statementMeta');
    const deleteButton = document.getElementById('deleteSelectedStatement');
    const openButton = document.getElementById('openSelectedStatement');

    if (!option || option.value === 'all') {
        meta.textContent = 'Toutes les opérations du compte sont affichées.';
        deleteButton.disabled = true;
        openButton.disabled = true;
        return;
    }

    meta.textContent = `${option.dataset.transactionsCount || 0} opération(s) — ${option.dataset.receiptsCount || 0} justificatif(s) lié(s).`;
    deleteButton.disabled = false;
    openButton.disabled = false;
}

async function loadSummary() {
    if (!selectedBankAccount) return;

    const summary = await window.api.getTransactionSummary({
        bankAccountId: selectedBankAccount.id,
        filters: getFilters()
    });

    document.getElementById('summaryTotal').textContent = summary.total;
    document.getElementById('summaryAttached').textContent = summary.attached;
    document.getElementById('summaryMissing').textContent = summary.missing;
    document.getElementById('summaryCredit').textContent = formatAmount(summary.credit);
    document.getElementById('summaryDebit').textContent = formatAmount(summary.debit);
}

async function loadTransactions() {
    if (!selectedBankAccount) return;

    const transactions = await window.api.getTransactions({
        bankAccountId: selectedBankAccount.id,
        filters: getFilters()
    });

    const body = document.getElementById('transactionTableBody');
    body.innerHTML = '';

    if (transactions.length === 0) {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td colspan="6" class="muted">Aucune opération ne correspond aux filtres.</td>';
        body.appendChild(tr);
        return;
    }

    transactions.forEach(transaction => {
        const tr = document.createElement('tr');
        tr.className = 'transaction-row';

        const amount = Number(transaction.amount || 0);
        const amountClass = amount >= 0 ? 'amount-credit' : 'amount-debit';

        tr.innerHTML = `
            <td>${transaction.date_operation || ''}</td>
            <td>${transaction.label || ''}</td>
            <td class="${amountClass}">${formatAmount(amount)}</td>
            <td>${getStatusLabel(transaction.status)}</td>
            <td>${transaction.receipts_count || 0}</td>
            <td>${transaction.statement_filename || ''}</td>
        `;

        tr.addEventListener('click', async () => {
            await showTransactionDetail(transaction.id);
        });

        body.appendChild(tr);
    });
}

async function showTransactionDetail(transactionId) {
    const transaction = await window.api.getTransaction(transactionId);
    selectedTransaction = transaction;

    document.getElementById('transactionDetailEmpty').style.display = 'none';
    document.getElementById('transactionDetail').style.display = 'block';

    document.getElementById('detailDate').textContent = transaction.date_operation || '';
    document.getElementById('detailLabel').textContent = transaction.label || '';
    document.getElementById('detailAmount').textContent = formatAmount(transaction.amount);
    document.getElementById('detailStatement').textContent = transaction.statement_filename || '';
    document.getElementById('detailStatus').value = transaction.status || 'missing';
    document.getElementById('detailCategory').value = transaction.category || '';
    document.getElementById('detailNotes').value = transaction.notes || '';

    await loadReceipts(transaction.id);
}

function updateReceiptPreview(receipt) {
    const preview = document.getElementById('receiptPreview');
    const filename = receipt.filename.toLowerCase();

    if (filename.endsWith('.jpg') || filename.endsWith('.jpeg') || filename.endsWith('.png') || filename.endsWith('.webp')) {
        preview.className = 'receipt-preview';
        preview.innerHTML = `<img src="file:///${receipt.filepath.replace(/\\/g, '/')}" alt="${receipt.filename}">`;
        return;
    }

    if (filename.endsWith('.pdf')) {
        preview.className = 'receipt-preview pdf-preview';
        preview.innerHTML = `📄 ${receipt.filename}<br><span class="muted">Clique sur “Ouvrir” pour consulter le PDF.</span>`;
        return;
    }

    preview.className = 'receipt-preview muted';
    preview.textContent = receipt.filename;
}

async function loadReceipts(transactionId) {
    const receipts = await window.api.getReceipts(transactionId);
    const list = document.getElementById('receiptList');
    list.innerHTML = '';

    const preview = document.getElementById('receiptPreview');
    preview.className = 'receipt-preview muted';
    preview.textContent = 'Aucun aperçu sélectionné.';

    if (receipts.length === 0) {
        const li = document.createElement('li');
        li.className = 'muted';
        li.textContent = 'Aucun justificatif attaché.';
        list.appendChild(li);
        return;
    }

    updateReceiptPreview(receipts[0]);

    receipts.forEach(receipt => {
        const li = document.createElement('li');
        li.className = 'receipt-item';

        const info = document.createElement('span');
        info.textContent = `${receipt.filename} — ${receipt.added_at}`;

        const previewButton = document.createElement('button');
        previewButton.textContent = 'Aperçu';
        previewButton.addEventListener('click', () => updateReceiptPreview(receipt));

        const openButton = document.createElement('button');
        openButton.textContent = 'Ouvrir';
        openButton.addEventListener('click', async () => {
            await window.api.openFile(receipt.filepath);
        });

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Supprimer';
        deleteButton.className = 'danger-button';
        deleteButton.addEventListener('click', async () => {
            const confirmDelete = confirm(`Supprimer ce justificatif ?\n\n${receipt.filename}`);
            if (!confirmDelete) return;

            await window.api.deleteReceipt(receipt.id);
            await showTransactionDetail(transactionId);
            await refreshAccountView(false);
        });

        li.appendChild(info);
        li.appendChild(previewButton);
        li.appendChild(openButton);
        li.appendChild(deleteButton);
        list.appendChild(li);
    });
}

document.getElementById('newCompany').addEventListener('click', async () => {
    const input = document.getElementById('companyName');
    const name = input.value.trim();

    if (!name) return;

    await window.api.addCompany(name);
    input.value = '';
    await loadCompanies();
});

document.getElementById('newBankAccount').addEventListener('click', async () => {
    if (!selectedCompany) return;

    const bankNameInput = document.getElementById('bankName');
    const accountNameInput = document.getElementById('accountName');
    const ibanInput = document.getElementById('iban');

    const bankName = bankNameInput.value.trim();
    const accountName = accountNameInput.value.trim();
    const iban = ibanInput.value.trim();

    if (!bankName) return;

    await window.api.addBankAccount({
        companyId: selectedCompany.id,
        bankName,
        accountName,
        iban
    });

    bankNameInput.value = '';
    accountNameInput.value = '';
    ibanInput.value = '';

    await loadBankAccounts();
});

document.getElementById('importStatement').addEventListener('click', async () => {
    if (!selectedBankAccount) return;

    const pdf = await window.api.selectPdf();
    if (!pdf) return;

    const result = await window.api.addStatement({
        bankAccountId: selectedBankAccount.id,
        filename: pdf.filename,
        filepath: pdf.filepath
    });

    if (!result.imported) {
        alert(result.message);
    } else {
        alert(`${result.transactionsCount} opération(s) détectée(s)`);
        selectedStatementId = String(result.statementId);
    }

    await refreshAccountView(true);
});

document.getElementById('statementSelect').addEventListener('change', async () => {
    selectedStatementId = document.getElementById('statementSelect').value || 'all';
    updateStatementMeta();
    resetTransactionDetail();
    await loadSummary();
    await loadTransactions();
});

document.getElementById('openSelectedStatement').addEventListener('click', async () => {
    const option = getSelectedStatementOption();
    if (!option || option.value === 'all') return;

    await window.api.openFile(option.dataset.filepath);
});

document.getElementById('deleteSelectedStatement').addEventListener('click', async () => {
    const option = getSelectedStatementOption();
    if (!option || option.value === 'all') return;

    const confirmDelete = confirm(
        `Supprimer ce relevé ?\n\n${option.dataset.filename}\n\n` +
        `${option.dataset.transactionsCount || 0} opération(s) et ${option.dataset.receiptsCount || 0} justificatif(s) lié(s) seront supprimés.`
    );

    if (!confirmDelete) return;

    await window.api.deleteStatement(Number(option.value));
    selectedStatementId = 'all';
    resetTransactionDetail();
    await refreshAccountView(true);
});

document.getElementById('saveTransactionDetails').addEventListener('click', async () => {
    if (!selectedTransaction) return;

    const status = document.getElementById('detailStatus').value;
    const category = document.getElementById('detailCategory').value.trim();
    const notes = document.getElementById('detailNotes').value.trim();

    await window.api.updateTransactionStatus({
        transactionId: selectedTransaction.id,
        status
    });

    await window.api.updateTransactionDetails({
        transactionId: selectedTransaction.id,
        category,
        notes
    });

    await showTransactionDetail(selectedTransaction.id);
    await refreshAccountView(false);
});

document.getElementById('addReceipt').addEventListener('click', async () => {
    if (!selectedTransaction) return;

    const receipt = await window.api.selectReceipt();
    if (!receipt) return;

    await window.api.addReceipt({
        transactionId: selectedTransaction.id,
        filename: receipt.filename,
        filepath: receipt.filepath
    });

    await showTransactionDetail(selectedTransaction.id);
    await refreshAccountView(false);
});

document.getElementById('searchInput').addEventListener('input', () => {
    clearTimeout(searchTimer);

    searchTimer = setTimeout(async () => {
        resetTransactionDetail();
        await loadSummary();
        await loadTransactions();
    }, 200);
});

['yearFilter', 'monthFilter', 'statusFilter'].forEach(id => {
    document.getElementById(id).addEventListener('change', async () => {
        resetTransactionDetail();
        await loadSummary();
        await loadTransactions();
    });
});

document.getElementById('resetFilters').addEventListener('click', async () => {
    document.getElementById('searchInput').value = '';
    document.getElementById('yearFilter').value = 'all';
    document.getElementById('monthFilter').value = 'all';
    document.getElementById('statusFilter').value = 'all';
    selectedStatementId = 'all';

    const statementSelect = document.getElementById('statementSelect');
    if (statementSelect) statementSelect.value = 'all';
    updateStatementMeta();

    resetTransactionDetail();
    await loadSummary();
    await loadTransactions();
});

loadCompanies();
