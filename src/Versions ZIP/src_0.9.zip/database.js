const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, '..', 'ThetaCompta.db');
const db = new Database(dbPath);

db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bank_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    bank_name TEXT NOT NULL,
    account_name TEXT,
    iban TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(company_id) REFERENCES companies(id)
);

CREATE TABLE IF NOT EXISTS statements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bank_account_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    filepath TEXT NOT NULL,
    statement_year TEXT,
    statement_month TEXT,
    imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id)
);

CREATE TABLE IF NOT EXISTS bank_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bank_account_id INTEGER NOT NULL,
    statement_id INTEGER,
    date_operation TEXT,
    label TEXT,
    amount REAL,
    type TEXT,
    pdf_source TEXT,
    status TEXT DEFAULT 'missing',
    category TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id),
    FOREIGN KEY(statement_id) REFERENCES statements(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    filepath TEXT NOT NULL,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(transaction_id) REFERENCES bank_transactions(id) ON DELETE CASCADE
);
`);

function ensureColumn(tableName, columnName, definition) {
    const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
    const exists = columns.some(column => column.name === columnName);

    if (!exists) {
        db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
    }
}

ensureColumn('statements', 'statement_year', 'TEXT');
ensureColumn('statements', 'statement_month', 'TEXT');
ensureColumn('bank_transactions', 'statement_id', 'INTEGER');
ensureColumn('bank_transactions', 'status', "TEXT DEFAULT 'missing'");
ensureColumn('bank_transactions', 'category', 'TEXT');
ensureColumn('bank_transactions', 'notes', 'TEXT');

function createCompany(name) {
    return db.prepare(`
        INSERT INTO companies(name)
        VALUES(?)
    `).run(name);
}

function getCompanies() {
    return db.prepare(`
        SELECT *
        FROM companies
        ORDER BY name
    `).all();
}

function createBankAccount(companyId, bankName, accountName, iban) {
    return db.prepare(`
        INSERT INTO bank_accounts(company_id, bank_name, account_name, iban)
        VALUES(?, ?, ?, ?)
    `).run(companyId, bankName, accountName, iban);
}

function getBankAccounts(companyId) {
    return db.prepare(`
        SELECT *
        FROM bank_accounts
        WHERE company_id = ?
        ORDER BY bank_name, account_name
    `).all(companyId);
}

function createStatement(bankAccountId, filename, filepath, statementYear = null, statementMonth = null) {
    return db.prepare(`
        INSERT INTO statements(bank_account_id, filename, filepath, statement_year, statement_month)
        VALUES(?, ?, ?, ?, ?)
    `).run(bankAccountId, filename, filepath, statementYear, statementMonth);
}

function updateStatementPeriod(statementId, statementYear, statementMonth) {
    return db.prepare(`
        UPDATE statements
        SET statement_year = ?, statement_month = ?
        WHERE id = ?
    `).run(statementYear, statementMonth, statementId);
}

function getStatements(bankAccountId) {
    return db.prepare(`
        SELECT
            s.*,
            COUNT(t.id) AS transactions_count
        FROM statements s
        LEFT JOIN bank_transactions t ON t.statement_id = s.id
        WHERE s.bank_account_id = ?
        GROUP BY s.id
        ORDER BY COALESCE(s.statement_year, '') DESC,
                 COALESCE(s.statement_month, '') DESC,
                 s.imported_at DESC
    `).all(bankAccountId);
}

function statementExists(bankAccountId, filepath) {
    return db.prepare(`
        SELECT *
        FROM statements
        WHERE bank_account_id = ?
        AND filepath = ?
    `).get(bankAccountId, filepath);
}

function deleteStatement(statementId) {
    const transactionIds = db.prepare(`
        SELECT id
        FROM bank_transactions
        WHERE statement_id = ?
    `).all(statementId).map(row => row.id);

    const deleteReceipt = db.prepare(`
        DELETE FROM receipts
        WHERE transaction_id = ?
    `);

    const deleteTransaction = db.prepare(`
        DELETE FROM bank_transactions
        WHERE id = ?
    `);

    const deleteStatementRow = db.prepare(`
        DELETE FROM statements
        WHERE id = ?
    `);

    const transaction = db.transaction(() => {
        transactionIds.forEach(id => {
            deleteReceipt.run(id);
            deleteTransaction.run(id);
        });

        deleteStatementRow.run(statementId);
    });

    transaction();
    return true;
}

function createTransaction(bankAccountId, statementId, dateOperation, label, amount, type, pdfSource) {
    return db.prepare(`
        INSERT INTO bank_transactions(
            bank_account_id,
            statement_id,
            date_operation,
            label,
            amount,
            type,
            pdf_source,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'missing')
    `).run(bankAccountId, statementId, dateOperation, label, amount, type, pdfSource);
}

function buildTransactionWhere(filters = {}) {
    const where = ['t.bank_account_id = ?'];
    const params = [filters.bankAccountId];

    if (filters.search) {
        where.push(`(
            LOWER(t.label) LIKE ?
            OR LOWER(COALESCE(t.category, '')) LIKE ?
            OR LOWER(COALESCE(t.notes, '')) LIKE ?
            OR CAST(t.amount AS TEXT) LIKE ?
        )`);

        const q = `%${String(filters.search).toLowerCase()}%`;
        params.push(q, q, q, q);
    }

    if (filters.status && filters.status !== 'all') {
        where.push('t.status = ?');
        params.push(filters.status);
    }

    if (filters.year && filters.year !== 'all') {
        where.push('s.statement_year = ?');
        params.push(filters.year);
    }

    if (filters.month && filters.month !== 'all') {
        where.push('s.statement_month = ?');
        params.push(filters.month);
    }

    return {
        whereSql: where.join(' AND '),
        params
    };
}

function getTransactions(bankAccountId, filters = {}) {
    const built = buildTransactionWhere({
        ...filters,
        bankAccountId
    });

    return db.prepare(`
        SELECT
            t.*,
            s.filename AS statement_filename,
            s.statement_year,
            s.statement_month,
            COUNT(r.id) AS receipts_count
        FROM bank_transactions t
        LEFT JOIN statements s ON s.id = t.statement_id
        LEFT JOIN receipts r ON r.transaction_id = t.id
        WHERE ${built.whereSql}
        GROUP BY t.id
        ORDER BY
            COALESCE(s.statement_year, '') DESC,
            COALESCE(s.statement_month, '') DESC,
            t.id DESC
    `).all(...built.params);
}

function getTransaction(transactionId) {
    return db.prepare(`
        SELECT
            t.*,
            s.filename AS statement_filename,
            s.statement_year,
            s.statement_month,
            COUNT(r.id) AS receipts_count
        FROM bank_transactions t
        LEFT JOIN statements s ON s.id = t.statement_id
        LEFT JOIN receipts r ON r.transaction_id = t.id
        WHERE t.id = ?
        GROUP BY t.id
    `).get(transactionId);
}

function updateTransactionStatus(transactionId, status) {
    return db.prepare(`
        UPDATE bank_transactions
        SET status = ?
        WHERE id = ?
    `).run(status, transactionId);
}

function updateTransactionDetails(transactionId, category, notes) {
    return db.prepare(`
        UPDATE bank_transactions
        SET category = ?, notes = ?
        WHERE id = ?
    `).run(category, notes, transactionId);
}

function createReceipt(transactionId, filename, filepath) {
    const result = db.prepare(`
        INSERT INTO receipts(transaction_id, filename, filepath)
        VALUES(?, ?, ?)
    `).run(transactionId, filename, filepath);

    db.prepare(`
        UPDATE bank_transactions
        SET status = 'attached'
        WHERE id = ?
        AND status = 'missing'
    `).run(transactionId);

    return result;
}

function getReceipts(transactionId) {
    return db.prepare(`
        SELECT *
        FROM receipts
        WHERE transaction_id = ?
        ORDER BY added_at DESC
    `).all(transactionId);
}

function deleteReceipt(receiptId) {
    const receipt = db.prepare(`
        SELECT *
        FROM receipts
        WHERE id = ?
    `).get(receiptId);

    if (!receipt) return false;

    db.prepare(`
        DELETE FROM receipts
        WHERE id = ?
    `).run(receiptId);

    const remaining = db.prepare(`
        SELECT COUNT(*) AS count
        FROM receipts
        WHERE transaction_id = ?
    `).get(receipt.transaction_id).count;

    if (remaining === 0) {
        db.prepare(`
            UPDATE bank_transactions
            SET status = 'missing'
            WHERE id = ?
            AND status = 'attached'
        `).run(receipt.transaction_id);
    }

    return true;
}

function getTransactionSummary(bankAccountId, filters = {}) {
    const built = buildTransactionWhere({
        ...filters,
        bankAccountId
    });

    const row = db.prepare(`
        SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN t.status = 'missing' THEN 1 ELSE 0 END) AS missing,
            SUM(CASE WHEN t.status IN ('attached', 'verified') THEN 1 ELSE 0 END) AS attached,
            COALESCE(SUM(CASE WHEN t.amount > 0 THEN t.amount ELSE 0 END), 0) AS credit,
            COALESCE(SUM(CASE WHEN t.amount < 0 THEN t.amount ELSE 0 END), 0) AS debit
        FROM bank_transactions t
        LEFT JOIN statements s ON s.id = t.statement_id
        WHERE ${built.whereSql}
    `).get(...built.params);

    return {
        total: row.total || 0,
        missing: row.missing || 0,
        attached: row.attached || 0,
        credit: row.credit || 0,
        debit: row.debit || 0
    };
}

function getAvailablePeriods(bankAccountId) {
    return db.prepare(`
        SELECT DISTINCT statement_year AS year, statement_month AS month
        FROM statements
        WHERE bank_account_id = ?
        AND statement_year IS NOT NULL
        AND statement_month IS NOT NULL
        ORDER BY statement_year DESC, statement_month DESC
    `).all(bankAccountId);
}

module.exports = {
    db,

    createCompany,
    getCompanies,

    createBankAccount,
    getBankAccounts,

    createStatement,
    updateStatementPeriod,
    getStatements,
    statementExists,
    deleteStatement,

    createTransaction,
    getTransactions,
    getTransaction,
    updateTransactionStatus,
    updateTransactionDetails,
    getTransactionSummary,
    getAvailablePeriods,

    createReceipt,
    getReceipts,
    deleteReceipt
};
