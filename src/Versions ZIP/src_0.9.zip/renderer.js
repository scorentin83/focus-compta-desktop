let selectedCompany = null;
let selectedBankAccount = null;
let selectedTransaction = null;
let searchTimer = null;

const MONTH_LABELS = {
    '01': 'Janvier',
    '02': 'Février',
    '03': 'Mars',
    '04': 'Avril',
    '05': 'Mai',
    '06': 'Juin',
    '07': 'Juillet',
    '08': 'Août',
    '09': 'Septembre',
    '10': 'Octobre',
    '11': 'Novembre',
    '12': 'Décembre'
};

function formatAmount(value) {
    return Number(value || 0).toLocaleString('fr-FR', {
        style: 'currency',
        currency: 'EUR'
    });
}

function getStatusLabel(status) {
    const labels = {
        missing: '❌ Manquant',
        attached: '📎 Pièce jointe',
        verified: '✅ Vérifié',
        review: '⚠️ À vérifier',
        ignored: 'Ignoré'
    };

    return labels[status] || '❌ Manquant';
}

function getFilters() {
    return {
        search: document.getElementById('searchInput')?.value.trim() || '',
        year: document.getElementById('yearFilter')?.value || 'all',
        month: document.getElementById('monthFilter')?.value || 'all',
        status: document.getElementById('statusFilter')?.value || 'all'
    };
}

function resetTransactionDetail() {
    selectedTransaction = null;
    document.getElementById('transactionDetailEmpty').style.display = 'block';
    document.getElementById('transactionDetail').style.display = 'none';
    document.getElementById('receiptPreview').textContent = 'Aucun aperçu sélectionné.';
    document.getElementById('receiptPreview').className = 'receipt-preview muted';
}

async function loadCompanies() {
    const companies = await window.api.getCompanies();

    const list = document.getElementById('companyList');
    list.innerHTML = '';

    companies.forEach(company => {
        const li = document.createElement('li');
        li.textContent = company.name;
        li.className = 'clickable';

        li.addEventListener('click', async () => {
            selectedCompany = company;
            selectedBankAccount = null;

            document.getElementById('selectedCompanyTitle').textContent = company.name;
            document.getElementById('bankSection').style.display = 'block';
            document.getElementById('selectedAccountTitle').textContent = 'Sélectionne un compte bancaire';
            document.getElementById('statementSection').style.display = 'none';
            document.getElementById('summaryCards').style.display = 'none';
            document.getElementById('toolsPanel').style.display = 'none';
            document.getElementById('statementHistory').style.display = 'none';
            document.getElementById('transactionTable').style.display = 'none';

            resetTransactionDetail();
            await loadBankAccounts();
        });

        list.appendChild(li);
    });
}

async function loadBankAccounts() {
    if (!selectedCompany) return;

    const accounts = await window.api.getBankAccounts(selectedCompany.id);

    const list = document.getElementById('bankAccountList');
    list.innerHTML = '';

    accounts.forEach(account => {
        const li = document.createElement('li');

        const title = [
            account.bank_name,
            account.account_name,
            account.iban
        ].filter(Boolean).join(' — ');

        li.textContent = title;
        li.className = 'clickable';

        li.addEventListener('click', async () => {
            selectedBankAccount = account;

            document.getElementById('selectedAccountTitle').textContent = title;
            document.getElementById('statementSection').style.display = 'block';
            document.getElementById('summaryCards').style.display = 'grid';
            document.getElementById('toolsPanel').style.display = 'grid';
            document.getElementById('statementHistory').style.display = 'block';
            document.getElementById('transactionTable').style.display = 'table';

            resetTransactionDetail();
            await refreshAccountView(true);
        });

        list.appendChild(li);
    });
}

async function refreshAccountView(refreshPeriods = false) {
    if (refreshPeriods) {
        await loadAvailablePeriods();
    }

    await loadStatements();
    await loadSummary();
    await loadTransactions();
}

async function loadAvailablePeriods() {
    if (!selectedBankAccount) return;

    const periods = await window.api.getAvailablePeriods(selectedBankAccount.id);
    const yearFilter = document.getElementById('yearFilter');
    const monthFilter = document.getElementById('monthFilter');

    const selectedYear = yearFilter.value || 'all';
    const selectedMonth = monthFilter.value || 'all';

    const years = [...new Set(periods.map(period => period.year).filter(Boolean))];
    const months = [...new Set(periods.map(period => period.month).filter(Boolean))].sort();

    yearFilter.innerHTML = '<option value="all">Toutes</option>';
    years.forEach(year => {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearFilter.appendChild(option);
    });

    monthFilter.innerHTML = '<option value="all">Tous</option>';
    months.forEach(month => {
        const option = document.createElement('option');
        option.value = month;
        option.textContent = MONTH_LABELS[month] || month;
        monthFilter.appendChild(option);
    });

    yearFilter.value = years.includes(selectedYear) ? selectedYear : 'all';
    monthFilter.value = months.includes(selectedMonth) ? selectedMonth : 'all';
}

async function loadStatements() {
    if (!selectedBankAccount) return;

    const statements = await window.api.getStatements(selectedBankAccount.id);
    const list = document.getElementById('statementList');
    list.innerHTML = '';

    if (statements.length === 0) {
        list.innerHTML = '<div class="empty-state small">Aucun relevé importé.</div>';
        return;
    }

    statements.forEach(statement => {
        const row = document.createElement('div');
        row.className = 'statement-item';

        const period = statement.statement_year && statement.statement_month
            ? `${MONTH_LABELS[statement.statement_month] || statement.statement_month} ${statement.statement_year}`
            : 'Période inconnue';

        row.innerHTML = `
            <div class="statement-main">
                <strong>${statement.filename}</strong>
                <span>${period} — importé le ${statement.imported_at} — ${statement.transactions_count || 0} opération(s)</span>
            </div>
            <div class="statement-buttons">
                <button data-action="open">Ouvrir</button>
                <button data-action="delete" class="danger-button">Supprimer</button>
            </div>
        `;

        row.querySelector('[data-action="open"]').addEventListener('click', async () => {
            await window.api.openFile(statement.filepath);
        });

        row.querySelector('[data-action="delete"]').addEventListener('click', async () => {
            const confirmDelete = confirm(
                `Supprimer ce relevé ?\n\n${statement.filename}\n\n${statement.transactions_count || 0} opération(s) seront supprimée(s).`
            );

            if (!confirmDelete) return;

            await window.api.deleteStatement(statement.id);
            resetTransactionDetail();
            await refreshAccountView(true);
        });

        list.appendChild(row);
    });
}

async function loadSummary() {
    if (!selectedBankAccount) return;

    const summary = await window.api.getTransactionSummary({
        bankAccountId: selectedBankAccount.id,
        filters: getFilters()
    });

    document.getElementById('summaryTotal').textContent = summary.total;
    document.getElementById('summaryAttached').textContent = summary.attached;
    document.getElementById('summaryMissing').textContent = summary.missing;
    document.getElementById('summaryCredit').textContent = formatAmount(summary.credit);
    document.getElementById('summaryDebit').textContent = formatAmount(summary.debit);
}

async function loadTransactions() {
    if (!selectedBankAccount) return;

    const transactions = await window.api.getTransactions({
        bankAccountId: selectedBankAccount.id,
        filters: getFilters()
    });

    const body = document.getElementById('transactionTableBody');
    body.innerHTML = '';

    if (transactions.length === 0) {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td colspan="6" class="muted">Aucune opération ne correspond aux filtres.</td>';
        body.appendChild(tr);
        return;
    }

    transactions.forEach(transaction => {
        const tr = document.createElement('tr');
        tr.className = 'transaction-row';

        const amount = Number(transaction.amount || 0);
        const amountClass = amount >= 0 ? 'amount-credit' : 'amount-debit';

        tr.innerHTML = `
            <td>${transaction.date_operation || ''}</td>
            <td>${transaction.label || ''}</td>
            <td class="${amountClass}">${formatAmount(amount)}</td>
            <td>${getStatusLabel(transaction.status)}</td>
            <td>${transaction.receipts_count || 0}</td>
            <td>${transaction.statement_filename || ''}</td>
        `;

        tr.addEventListener('click', async () => {
            await showTransactionDetail(transaction.id);
        });

        body.appendChild(tr);
    });
}

async function showTransactionDetail(transactionId) {
    const transaction = await window.api.getTransaction(transactionId);
    selectedTransaction = transaction;

    document.getElementById('transactionDetailEmpty').style.display = 'none';
    document.getElementById('transactionDetail').style.display = 'block';

    document.getElementById('detailDate').textContent = transaction.date_operation || '';
    document.getElementById('detailLabel').textContent = transaction.label || '';
    document.getElementById('detailAmount').textContent = formatAmount(transaction.amount);
    document.getElementById('detailStatement').textContent = transaction.statement_filename || '';
    document.getElementById('detailStatus').value = transaction.status || 'missing';
    document.getElementById('detailCategory').value = transaction.category || '';
    document.getElementById('detailNotes').value = transaction.notes || '';

    await loadReceipts(transaction.id);
}

function updateReceiptPreview(receipt) {
    const preview = document.getElementById('receiptPreview');
    const filename = receipt.filename.toLowerCase();

    if (filename.endsWith('.jpg') || filename.endsWith('.jpeg') || filename.endsWith('.png') || filename.endsWith('.webp')) {
        preview.className = 'receipt-preview';
        preview.innerHTML = `<img src="file:///${receipt.filepath.replace(/\\/g, '/')}" alt="${receipt.filename}">`;
        return;
    }

    if (filename.endsWith('.pdf')) {
        preview.className = 'receipt-preview pdf-preview';
        preview.innerHTML = `📄 ${receipt.filename}<br><span class="muted">Clique sur “Ouvrir” pour consulter le PDF.</span>`;
        return;
    }

    preview.className = 'receipt-preview muted';
    preview.textContent = receipt.filename;
}

async function loadReceipts(transactionId) {
    const receipts = await window.api.getReceipts(transactionId);
    const list = document.getElementById('receiptList');
    list.innerHTML = '';

    const preview = document.getElementById('receiptPreview');
    preview.className = 'receipt-preview muted';
    preview.textContent = 'Aucun aperçu sélectionné.';

    if (receipts.length === 0) {
        const li = document.createElement('li');
        li.className = 'muted';
        li.textContent = 'Aucun justificatif attaché.';
        list.appendChild(li);
        return;
    }

    updateReceiptPreview(receipts[0]);

    receipts.forEach(receipt => {
        const li = document.createElement('li');
        li.className = 'receipt-item';

        const info = document.createElement('span');
        info.textContent = `${receipt.filename} — ${receipt.added_at}`;

        const previewButton = document.createElement('button');
        previewButton.textContent = 'Aperçu';
        previewButton.addEventListener('click', () => updateReceiptPreview(receipt));

        const openButton = document.createElement('button');
        openButton.textContent = 'Ouvrir';
        openButton.addEventListener('click', async () => {
            await window.api.openFile(receipt.filepath);
        });

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Supprimer';
        deleteButton.className = 'danger-button';
        deleteButton.addEventListener('click', async () => {
            const confirmDelete = confirm(`Supprimer ce justificatif ?\n\n${receipt.filename}`);

            if (!confirmDelete) return;

            await window.api.deleteReceipt(receipt.id);
            await showTransactionDetail(transactionId);
            await refreshAccountView(false);
        });

        li.appendChild(info);
        li.appendChild(previewButton);
        li.appendChild(openButton);
        li.appendChild(deleteButton);
        list.appendChild(li);
    });
}

document.getElementById('newCompany').addEventListener('click', async () => {
    const input = document.getElementById('companyName');
    const name = input.value.trim();

    if (!name) return;

    await window.api.addCompany(name);

    input.value = '';
    await loadCompanies();
});

document.getElementById('newBankAccount').addEventListener('click', async () => {
    if (!selectedCompany) return;

    const bankNameInput = document.getElementById('bankName');
    const accountNameInput = document.getElementById('accountName');
    const ibanInput = document.getElementById('iban');

    const bankName = bankNameInput.value.trim();
    const accountName = accountNameInput.value.trim();
    const iban = ibanInput.value.trim();

    if (!bankName) return;

    await window.api.addBankAccount({
        companyId: selectedCompany.id,
        bankName,
        accountName,
        iban
    });

    bankNameInput.value = '';
    accountNameInput.value = '';
    ibanInput.value = '';

    await loadBankAccounts();
});

document.getElementById('importStatement').addEventListener('click', async () => {
    if (!selectedBankAccount) return;

    const pdf = await window.api.selectPdf();
    if (!pdf) return;

    const result = await window.api.addStatement({
        bankAccountId: selectedBankAccount.id,
        filename: pdf.filename,
        filepath: pdf.filepath
    });

    if (!result.imported) {
        alert(result.message);
    } else {
        alert(`${result.transactionsCount} opération(s) détectée(s)`);
    }

    await refreshAccountView(true);
});

document.getElementById('saveTransactionDetails').addEventListener('click', async () => {
    if (!selectedTransaction) return;

    const status = document.getElementById('detailStatus').value;
    const category = document.getElementById('detailCategory').value.trim();
    const notes = document.getElementById('detailNotes').value.trim();

    await window.api.updateTransactionStatus({
        transactionId: selectedTransaction.id,
        status
    });

    await window.api.updateTransactionDetails({
        transactionId: selectedTransaction.id,
        category,
        notes
    });

    await showTransactionDetail(selectedTransaction.id);
    await refreshAccountView(false);
});

document.getElementById('addReceipt').addEventListener('click', async () => {
    if (!selectedTransaction) return;

    const receipt = await window.api.selectReceipt();
    if (!receipt) return;

    await window.api.addReceipt({
        transactionId: selectedTransaction.id,
        filename: receipt.filename,
        filepath: receipt.filepath
    });

    await showTransactionDetail(selectedTransaction.id);
    await refreshAccountView(false);
});

document.getElementById('searchInput').addEventListener('input', () => {
    clearTimeout(searchTimer);

    searchTimer = setTimeout(async () => {
        await loadSummary();
        await loadTransactions();
        resetTransactionDetail();
    }, 250);
});

['yearFilter', 'monthFilter', 'statusFilter'].forEach(id => {
    document.getElementById(id).addEventListener('change', async () => {
        await loadSummary();
        await loadTransactions();
        resetTransactionDetail();
    });
});

document.getElementById('resetFilters').addEventListener('click', async () => {
    document.getElementById('searchInput').value = '';
    document.getElementById('yearFilter').value = 'all';
    document.getElementById('monthFilter').value = 'all';
    document.getElementById('statusFilter').value = 'all';

    await loadSummary();
    await loadTransactions();
    resetTransactionDetail();
});

loadCompanies();
