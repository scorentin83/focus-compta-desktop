const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const pdfParseModule = require('pdf-parse');

const PDFParse = pdfParseModule.PDFParse;

const {
    createCompany,
    getCompanies,
    createBankAccount,
    getBankAccounts,
    createStatement,
    updateStatementPeriod,
    getStatements,
    statementExists,
    deleteStatement,
    createTransaction,
    getTransactions,
    getTransaction,
    updateTransactionStatus,
    updateTransactionDetails,
    getTransactionSummary,
    getAvailablePeriods,
    createReceipt,
    getReceipts,
    deleteReceipt
} = require('./database');

function createWindow() {
    const win = new BrowserWindow({
        width: 1700,
        height: 1000,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }
    });

    win.loadFile(path.join(__dirname, 'index.html'));
}

function parseFrenchAmount(value) {
    return Number(
        String(value)
            .replace(/\s/g, '')
            .replace(',', '.')
    );
}

function normalizeDate(value) {
    return String(value).replace('.', '/');
}

function monthNameToNumber(value) {
    const normalized = String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');

    const months = {
        janvier: '01',
        fevrier: '02',
        mars: '03',
        avril: '04',
        mai: '05',
        juin: '06',
        juillet: '07',
        aout: '08',
        septembre: '09',
        octobre: '10',
        novembre: '11',
        decembre: '12'
    };

    return months[normalized] || null;
}

function extractStatementPeriod(text, filename) {
    const dateMatch = text.match(/Date d[’']arrêté\s*:\s*(\d{1,2})\s+([A-Za-zéûîôàèùç]+)\s+(\d{4})/i);

    if (dateMatch) {
        return {
            year: dateMatch[3],
            month: monthNameToNumber(dateMatch[2])
        };
    }

    const filenameMatch = String(filename).match(/(\d{2})-(\d{2})-(\d{4})/);

    if (filenameMatch) {
        return {
            year: filenameMatch[3],
            month: filenameMatch[2]
        };
    }

    return {
        year: null,
        month: null
    };
}

function getAmountAndLabel(rawLabelWithAmount) {
    const amountPattern = /((?:\d{1,3}(?:\s\d{3})+|\d+),\d{2})\s*¨?$/;
    const match = rawLabelWithAmount.match(amountPattern);

    if (!match) return null;

    const amountRaw = match[1];
    const label = rawLabelWithAmount.slice(0, match.index).trim();

    return {
        label,
        amount: parseFrenchAmount(amountRaw)
    };
}

function guessTransactionType(label) {
    const lowerLabel = String(label || '').toLowerCase();

    const debitKeywords = [
        'prlv',
        ' vers ',
        'vir inst vers',
        'cotis',
        'frais',
        'facture crédit agricole'
    ];

    return debitKeywords.some(keyword => lowerLabel.includes(keyword)) ? 'debit' : 'credit';
}

function parseCreditAgricoleTransactions(text, bankAccountId, statementId, filename) {
    const lines = text
        .split(/\r?\n/)
        .map(line => line.trim())
        .filter(Boolean);

    const transactions = [];
    const operationStartRegex = /^(\d{2}\.\d{2})\s+(\d{2}\.\d{2})\s+(.+)$/;

    for (const line of lines) {
        if (
            line.includes('Ancien solde') ||
            line.includes('Nouveau solde') ||
            line.includes('Total des opérations') ||
            line.includes('Date opé') ||
            line.includes('Date valeur') ||
            line.includes('RELEVE DE COMPTES') ||
            line.includes('Compte Courant')
        ) {
            continue;
        }

        const match = line.match(operationStartRegex);
        if (!match) continue;

        const amountAndLabel = getAmountAndLabel(match[3]);
        if (!amountAndLabel) continue;

        const dateOperation = normalizeDate(match[1]);
        const label = amountAndLabel.label;
        const amount = amountAndLabel.amount;
        const type = guessTransactionType(label);
        const signedAmount = type === 'debit' ? -amount : amount;

        const transaction = {
            bankAccountId,
            statementId,
            dateOperation,
            label,
            amount: signedAmount,
            type,
            pdfSource: filename
        };

        createTransaction(
            transaction.bankAccountId,
            transaction.statementId,
            transaction.dateOperation,
            transaction.label,
            transaction.amount,
            transaction.type,
            transaction.pdfSource
        );

        transactions.push(transaction);
    }

    return transactions;
}

app.whenReady().then(() => {
    createWindow();
});

ipcMain.handle('add-company', async (event, name) => {
    createCompany(name);
    return true;
});

ipcMain.handle('get-companies', async () => {
    return getCompanies();
});

ipcMain.handle('add-bank-account', async (event, data) => {
    createBankAccount(data.companyId, data.bankName, data.accountName, data.iban);
    return true;
});

ipcMain.handle('get-bank-accounts', async (event, companyId) => {
    return getBankAccounts(companyId);
});

ipcMain.handle('select-pdf', async () => {
    const result = await dialog.showOpenDialog({
        title: 'Importer un relevé bancaire PDF',
        filters: [
            { name: 'PDF', extensions: ['pdf'] }
        ],
        properties: ['openFile']
    });

    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }

    const filepath = result.filePaths[0];
    const filename = path.basename(filepath);

    return { filename, filepath };
});

ipcMain.handle('add-statement', async (event, data) => {
    const existing = statementExists(data.bankAccountId, data.filepath);

    if (existing) {
        return {
            imported: false,
            message: 'PDF déjà importé',
            transactionsCount: 0
        };
    }

    const buffer = fs.readFileSync(data.filepath);
    const parser = new PDFParse({ data: buffer });
    const parsed = await parser.getText();
    const period = extractStatementPeriod(parsed.text, data.filename);

    const statementResult = createStatement(
        data.bankAccountId,
        data.filename,
        data.filepath,
        period.year,
        period.month
    );

    const statementId = statementResult.lastInsertRowid;

    const transactions = parseCreditAgricoleTransactions(
        parsed.text,
        data.bankAccountId,
        statementId,
        data.filename
    );

    updateStatementPeriod(statementId, period.year, period.month);

    return {
        imported: true,
        statementId,
        transactionsCount: transactions.length,
        statementYear: period.year,
        statementMonth: period.month
    };
});

ipcMain.handle('get-statements', async (event, bankAccountId) => {
    return getStatements(bankAccountId);
});

ipcMain.handle('delete-statement', async (event, statementId) => {
    return deleteStatement(statementId);
});

ipcMain.handle('get-transactions', async (event, data) => {
    if (typeof data === 'number') {
        return getTransactions(data, {});
    }

    return getTransactions(data.bankAccountId, data.filters || {});
});

ipcMain.handle('get-transaction', async (event, transactionId) => {
    return getTransaction(transactionId);
});

ipcMain.handle('update-transaction-status', async (event, data) => {
    updateTransactionStatus(data.transactionId, data.status);
    return true;
});

ipcMain.handle('update-transaction-details', async (event, data) => {
    updateTransactionDetails(data.transactionId, data.category, data.notes);
    return true;
});

ipcMain.handle('get-transaction-summary', async (event, data) => {
    if (typeof data === 'number') {
        return getTransactionSummary(data, {});
    }

    return getTransactionSummary(data.bankAccountId, data.filters || {});
});

ipcMain.handle('get-available-periods', async (event, bankAccountId) => {
    return getAvailablePeriods(bankAccountId);
});

ipcMain.handle('select-receipt', async () => {
    const result = await dialog.showOpenDialog({
        title: 'Ajouter un justificatif',
        filters: [
            { name: 'Documents', extensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'] }
        ],
        properties: ['openFile']
    });

    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }

    const filepath = result.filePaths[0];
    const filename = path.basename(filepath);

    return { filename, filepath };
});

ipcMain.handle('add-receipt', async (event, data) => {
    createReceipt(data.transactionId, data.filename, data.filepath);
    return true;
});

ipcMain.handle('get-receipts', async (event, transactionId) => {
    return getReceipts(transactionId);
});

ipcMain.handle('delete-receipt', async (event, receiptId) => {
    return deleteReceipt(receiptId);
});

ipcMain.handle('open-file', async (event, filepath) => {
    await shell.openPath(filepath);
    return true;
});
