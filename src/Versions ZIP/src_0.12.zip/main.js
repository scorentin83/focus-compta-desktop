const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const pdfParseModule = require('pdf-parse');

const PDFParse = pdfParseModule.PDFParse;

const {
    DATA_DIR,
    STATEMENTS_DIR,
    RECEIPTS_DIR,
    BACKUPS_DIR,
    DB_PATH,
    createCompany,
    getCompanies,
    createBankAccount,
    getBankAccounts,
    createStatement,
    updateStatementPeriod,
    getStatements,
    statementExists,
    getStatementFiles,
    deleteStatement,
    createTransaction,
    getTransactions,
    getTransaction,
    updateTransactionStatus,
    updateTransactionDetails,
    getTransactionSummary,
    getAvailablePeriods,
    createReceipt,
    getReceipt,
    getReceipts,
    deleteReceipt
} = require('./database');

function createWindow() {
    const win = new BrowserWindow({
        width: 1700,
        height: 1000,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }
    });

    win.loadFile(path.join(__dirname, 'index.html'));
}

function ensureDir(dir) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function safeFilename(filename) {
    const ext = path.extname(filename);
    const base = path.basename(filename, ext)
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9-_]+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '')
        .slice(0, 80) || 'document';

    return `${base}${ext.toLowerCase()}`;
}

function uniqueDestination(dir, filename) {
    ensureDir(dir);
    const ext = path.extname(filename);
    const base = path.basename(filename, ext);
    let destination = path.join(dir, filename);
    let counter = 1;

    while (fs.existsSync(destination)) {
        destination = path.join(dir, `${base}-${counter}${ext}`);
        counter += 1;
    }

    return destination;
}

function copyToFocusData(sourcePath, destinationDirParts) {
    const filename = safeFilename(path.basename(sourcePath));
    const destinationDir = path.join(...destinationDirParts);
    const destination = uniqueDestination(destinationDir, filename);
    fs.copyFileSync(sourcePath, destination);

    return {
        filename: path.basename(destination),
        filepath: destination
    };
}

function deleteFileIfInsideDataDir(filepath) {
    if (!filepath) return;

    const resolved = path.resolve(filepath);
    const dataRoot = path.resolve(DATA_DIR);

    if (!resolved.startsWith(dataRoot)) return;
    if (!fs.existsSync(resolved)) return;

    try {
        fs.unlinkSync(resolved);
    } catch (error) {
        console.warn('Impossible de supprimer le fichier :', resolved, error.message);
    }
}

function parseFrenchAmount(value) {
    return Number(
        String(value)
            .replace(/\s/g, '')
            .replace(',', '.')
    );
}

function normalizeDate(value) {
    return String(value).replace('.', '/');
}

function monthNameToNumber(value) {
    const normalized = String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '');

    const months = {
        janvier: '01',
        fevrier: '02',
        mars: '03',
        avril: '04',
        mai: '05',
        juin: '06',
        juillet: '07',
        aout: '08',
        septembre: '09',
        octobre: '10',
        novembre: '11',
        decembre: '12'
    };

    return months[normalized] || null;
}

function extractStatementPeriod(text, filename) {
    const dateMatch = text.match(/Date d[’']arrêté\s*:\s*(\d{1,2})\s+([A-Za-zéûîôàèùç]+)\s+(\d{4})/i);

    if (dateMatch) {
        return {
            year: dateMatch[3],
            month: monthNameToNumber(dateMatch[2])
        };
    }

    const filenameMatch = String(filename).match(/(\d{2})-(\d{2})-(\d{4})/);

    if (filenameMatch) {
        return {
            year: filenameMatch[3],
            month: filenameMatch[2]
        };
    }

    return {
        year: null,
        month: null
    };
}

function repairPotentiallyConcatenatedAmount(amountRaw, labelBeforeAmount) {
    const value = String(amountRaw || '').trim();
    const parts = value.split(',');

    if (parts.length !== 2) return value;

    const integerPart = parts[0].replace(/\s/g, '');
    const decimalPart = parts[1];

    if (integerPart.length <= 7) return value;

    // Cas Crédit Agricole observé : numéro de prêt ou référence collé au montant.
    // Exemple : 006049769888665,39 => 8 665,39
    if (integerPart.startsWith('00') && integerPart.length > 11) {
        const tail = integerPart.slice(11);
        if (tail.length >= 1 && tail.length <= 6) {
            return `${tail},${decimalPart}`;
        }
    }

    // Autre cas : référence courte collée à un montant, on garde une valeur plausible.
    const plausibleTail = integerPart.slice(-6).replace(/^0+/, '') || '0';
    return `${plausibleTail},${decimalPart}`;
}

function getAmountAndLabel(rawLabelWithAmount) {
    const text = String(rawLabelWithAmount || '').trim();

    const candidates = [...text.matchAll(/(\d[\d\s]*,\d{2})\s*¨?/g)];
    if (candidates.length === 0) return null;

    const last = candidates[candidates.length - 1];
    const originalAmountRaw = last[1];
    const amountStart = last.index;
    const label = text.slice(0, amountStart).trim();
    const amountRaw = repairPotentiallyConcatenatedAmount(originalAmountRaw, label);
    const amount = parseFrenchAmount(amountRaw);

    if (!Number.isFinite(amount)) return null;
    if (amount <= 0 || amount > 1000000) return null;

    return {
        label,
        amount
    };
}

function guessTransactionType(label) {
    const lowerLabel = String(label || '').toLowerCase();

    const debitRules = [
        /^prlv\b/,
        /^regul annul/i,
        /^virement\s+ag\b/i,
        /^virement\s+vir\s+inst\s+vers\b/i,
        /^virement\s+web\s+multitek\b/i,
        /^virement\s+web\s+simie\b/i,
        /^virement\s+web\s+soci[ée]t[ée]\s+caladoise\b/i,
        /cotis/i,
        /frais/i,
        /facture crédit agricole/i
    ];

    const creditRules = [
        /^real prêt\b/i,
        /^virement\s+apport\b/i,
        /^virement\s+focus\s+apport\b/i,
        /^virement\s+sauvage\b/i,
        /^virement\s+m\s+arnaud\b/i,
        /^virement\s+web\s+sas\s+focus\s+rbt\b/i
    ];

    if (creditRules.some(rule => rule.test(lowerLabel))) return 'credit';
    if (debitRules.some(rule => rule.test(lowerLabel))) return 'debit';

    return 'credit';
}

function parseCreditAgricoleTransactions(text, bankAccountId, statementId, filename) {
    const lines = text
        .split(/\r?\n/)
        .map(line => line.trim())
        .filter(Boolean);

    const transactions = [];
    const operationStartRegex = /^(\d{2}\.\d{2})\s+(\d{2}\.\d{2})\s+(.+)$/;

    for (const line of lines) {
        if (
            line.includes('Ancien solde') ||
            line.includes('Nouveau solde') ||
            line.includes('Total des opérations') ||
            line.includes('Date opé') ||
            line.includes('Date valeur') ||
            line.includes('RELEVE DE COMPTES') ||
            line.includes('Compte Courant')
        ) {
            continue;
        }

        const match = line.match(operationStartRegex);
        if (!match) continue;

        const amountAndLabel = getAmountAndLabel(match[3]);
        if (!amountAndLabel) continue;

        const dateOperation = normalizeDate(match[1]);
        const label = amountAndLabel.label;
        const amount = amountAndLabel.amount;
        const type = guessTransactionType(label);
        const signedAmount = type === 'debit' ? -amount : amount;

        const transaction = {
            bankAccountId,
            statementId,
            dateOperation,
            label,
            amount: signedAmount,
            type,
            pdfSource: filename
        };

        createTransaction(
            transaction.bankAccountId,
            transaction.statementId,
            transaction.dateOperation,
            transaction.label,
            transaction.amount,
            transaction.type,
            transaction.pdfSource
        );

        transactions.push(transaction);
    }

    return transactions;
}

function createLocalBackup() {
    ensureDir(BACKUPS_DIR);

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(BACKUPS_DIR, `FocusCompta-${timestamp}`);
    ensureDir(backupDir);

    if (fs.existsSync(DB_PATH)) {
        fs.copyFileSync(DB_PATH, path.join(backupDir, 'FocusCompta.db'));
    }

    if (fs.existsSync(DATA_DIR)) {
        const docsBackupDir = path.join(backupDir, 'FocusComptaData');
        fs.cpSync(DATA_DIR, docsBackupDir, { recursive: true });
    }

    return backupDir;
}

app.whenReady().then(() => {
    createWindow();
});

ipcMain.handle('add-company', async (event, name) => {
    createCompany(name);
    return true;
});

ipcMain.handle('get-companies', async () => {
    return getCompanies();
});

ipcMain.handle('add-bank-account', async (event, data) => {
    createBankAccount(data.companyId, data.bankName, data.accountName, data.iban);
    return true;
});

ipcMain.handle('get-bank-accounts', async (event, companyId) => {
    return getBankAccounts(companyId);
});

ipcMain.handle('select-pdf', async () => {
    const result = await dialog.showOpenDialog({
        title: 'Importer un relevé bancaire PDF',
        filters: [
            { name: 'PDF', extensions: ['pdf'] }
        ],
        properties: ['openFile']
    });

    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }

    const filepath = result.filePaths[0];
    const filename = path.basename(filepath);

    return { filename, filepath };
});

ipcMain.handle('add-statement', async (event, data) => {
    const existing = statementExists(data.bankAccountId, data.filepath);

    if (existing) {
        return {
            imported: false,
            message: 'PDF déjà importé',
            transactionsCount: 0
        };
    }

    const buffer = fs.readFileSync(data.filepath);
    const parser = new PDFParse({ data: buffer });
    const parsed = await parser.getText();
    const period = extractStatementPeriod(parsed.text, data.filename);

    const storedStatement = copyToFocusData(data.filepath, [
        STATEMENTS_DIR,
        period.year || 'SansAnnee',
        period.month || 'SansMois'
    ]);

    const statementResult = createStatement(
        data.bankAccountId,
        storedStatement.filename,
        storedStatement.filepath,
        data.filepath,
        period.year,
        period.month
    );

    const statementId = statementResult.lastInsertRowid;

    const transactions = parseCreditAgricoleTransactions(
        parsed.text,
        data.bankAccountId,
        statementId,
        storedStatement.filename
    );

    updateStatementPeriod(statementId, period.year, period.month);

    return {
        imported: true,
        statementId,
        transactionsCount: transactions.length,
        statementYear: period.year,
        statementMonth: period.month
    };
});

ipcMain.handle('get-statements', async (event, bankAccountId) => {
    return getStatements(bankAccountId);
});

ipcMain.handle('delete-statement', async (event, statementId) => {
    const files = getStatementFiles(statementId);
    const result = deleteStatement(statementId);

    if (result) {
        deleteFileIfInsideDataDir(files.statementFilepath);
        files.receiptFilepaths.forEach(deleteFileIfInsideDataDir);
    }

    return result;
});

ipcMain.handle('get-transactions', async (event, data) => {
    if (typeof data === 'number') {
        return getTransactions(data, {});
    }

    return getTransactions(data.bankAccountId, data.filters || {});
});

ipcMain.handle('get-transaction', async (event, transactionId) => {
    return getTransaction(transactionId);
});

ipcMain.handle('update-transaction-status', async (event, data) => {
    updateTransactionStatus(data.transactionId, data.status);
    return true;
});

ipcMain.handle('update-transaction-details', async (event, data) => {
    updateTransactionDetails(data.transactionId, data.category, data.notes);
    return true;
});

ipcMain.handle('get-transaction-summary', async (event, data) => {
    if (typeof data === 'number') {
        return getTransactionSummary(data, {});
    }

    return getTransactionSummary(data.bankAccountId, data.filters || {});
});

ipcMain.handle('get-available-periods', async (event, bankAccountId) => {
    return getAvailablePeriods(bankAccountId);
});

ipcMain.handle('select-receipt', async () => {
    const result = await dialog.showOpenDialog({
        title: 'Ajouter un justificatif',
        filters: [
            { name: 'Documents', extensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'] }
        ],
        properties: ['openFile']
    });

    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }

    const filepath = result.filePaths[0];
    const filename = path.basename(filepath);

    return { filename, filepath };
});

ipcMain.handle('add-receipt', async (event, data) => {
    const transaction = getTransaction(data.transactionId);
    const year = transaction?.statement_year || 'SansAnnee';
    const month = transaction?.statement_month || 'SansMois';

    const storedReceipt = copyToFocusData(data.filepath, [
        RECEIPTS_DIR,
        year,
        month
    ]);

    createReceipt(
        data.transactionId,
        storedReceipt.filename,
        storedReceipt.filepath,
        data.filepath
    );

    return true;
});

ipcMain.handle('get-receipts', async (event, transactionId) => {
    return getReceipts(transactionId);
});

ipcMain.handle('delete-receipt', async (event, receiptId) => {
    const receipt = getReceipt(receiptId);
    const result = deleteReceipt(receiptId);

    if (result && receipt) {
        deleteFileIfInsideDataDir(receipt.filepath);
    }

    return result;
});

ipcMain.handle('open-file', async (event, filepath) => {
    await shell.openPath(filepath);
    return true;
});

ipcMain.handle('create-backup', async () => {
    const backupDir = createLocalBackup();
    return {
        ok: true,
        backupDir
    };
});

ipcMain.handle('open-data-folder', async () => {
    await shell.openPath(DATA_DIR);
    return true;
});
