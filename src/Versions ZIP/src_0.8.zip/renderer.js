let selectedCompany = null;
let selectedBankAccount = null;
let selectedTransaction = null;

function formatAmount(value) {
    return Number(value || 0).toLocaleString('fr-FR', {
        style: 'currency',
        currency: 'EUR'
    });
}

function getStatusLabel(status) {
    const labels = {
        missing: '❌ Manquant',
        attached: '📎 Pièce jointe',
        verified: '✅ Vérifié',
        review: '⚠️ À vérifier',
        ignored: 'Ignoré'
    };

    return labels[status] || '❌ Manquant';
}

function resetTransactionDetail() {
    selectedTransaction = null;
    document.getElementById('transactionDetailEmpty').style.display = 'block';
    document.getElementById('transactionDetail').style.display = 'none';
}

async function loadCompanies() {
    const companies = await window.api.getCompanies();

    const list = document.getElementById('companyList');
    list.innerHTML = '';

    companies.forEach(company => {
        const li = document.createElement('li');
        li.textContent = company.name;
        li.className = 'clickable';

        li.addEventListener('click', async () => {
            selectedCompany = company;
            selectedBankAccount = null;

            document.getElementById('selectedCompanyTitle').textContent = company.name;
            document.getElementById('bankSection').style.display = 'block';
            document.getElementById('selectedAccountTitle').textContent = 'Sélectionne un compte bancaire';
            document.getElementById('statementSection').style.display = 'none';
            document.getElementById('summaryCards').style.display = 'none';
            document.getElementById('statementHistory').style.display = 'none';
            document.getElementById('transactionTable').style.display = 'none';

            resetTransactionDetail();
            await loadBankAccounts();
        });

        list.appendChild(li);
    });
}

async function loadBankAccounts() {
    if (!selectedCompany) return;

    const accounts = await window.api.getBankAccounts(selectedCompany.id);

    const list = document.getElementById('bankAccountList');
    list.innerHTML = '';

    accounts.forEach(account => {
        const li = document.createElement('li');

        const title = [
            account.bank_name,
            account.account_name,
            account.iban
        ].filter(Boolean).join(' — ');

        li.textContent = title;
        li.className = 'clickable';

        li.addEventListener('click', async () => {
            selectedBankAccount = account;

            document.getElementById('selectedAccountTitle').textContent = title;
            document.getElementById('statementSection').style.display = 'block';
            document.getElementById('summaryCards').style.display = 'grid';
            document.getElementById('statementHistory').style.display = 'block';
            document.getElementById('transactionTable').style.display = 'table';

            resetTransactionDetail();
            await refreshAccountView();
        });

        list.appendChild(li);
    });
}

async function refreshAccountView() {
    await loadStatements();
    await loadSummary();
    await loadTransactions();
}

async function loadStatements() {
    if (!selectedBankAccount) return;

    const statements = await window.api.getStatements(selectedBankAccount.id);

    const list = document.getElementById('statementList');
    list.innerHTML = '';

    statements.forEach(statement => {
        const li = document.createElement('li');
        li.textContent = `${statement.filename} — ${statement.imported_at}`;
        list.appendChild(li);
    });
}

async function loadSummary() {
    if (!selectedBankAccount) return;

    const summary = await window.api.getTransactionSummary(selectedBankAccount.id);

    document.getElementById('summaryTotal').textContent = summary.total;
    document.getElementById('summaryAttached').textContent = summary.attached;
    document.getElementById('summaryMissing').textContent = summary.missing;
    document.getElementById('summaryCredit').textContent = formatAmount(summary.credit);
    document.getElementById('summaryDebit').textContent = formatAmount(summary.debit);
}

async function loadTransactions() {
    if (!selectedBankAccount) return;

    const transactions = await window.api.getTransactions(selectedBankAccount.id);

    const body = document.getElementById('transactionTableBody');
    body.innerHTML = '';

    transactions.forEach(transaction => {
        const tr = document.createElement('tr');
        tr.className = 'transaction-row';

        const amount = Number(transaction.amount || 0);
        const amountClass = amount >= 0 ? 'amount-credit' : 'amount-debit';

        tr.innerHTML = `
            <td>${transaction.date_operation || ''}</td>
            <td>${transaction.label || ''}</td>
            <td class="${amountClass}">${formatAmount(amount)}</td>
            <td>${getStatusLabel(transaction.status)}</td>
            <td>${transaction.receipts_count || 0}</td>
        `;

        tr.addEventListener('click', async () => {
            await showTransactionDetail(transaction.id);
        });

        body.appendChild(tr);
    });
}

async function showTransactionDetail(transactionId) {
    const transaction = await window.api.getTransaction(transactionId);
    selectedTransaction = transaction;

    document.getElementById('transactionDetailEmpty').style.display = 'none';
    document.getElementById('transactionDetail').style.display = 'block';

    document.getElementById('detailDate').textContent = transaction.date_operation || '';
    document.getElementById('detailLabel').textContent = transaction.label || '';
    document.getElementById('detailAmount').textContent = formatAmount(transaction.amount);
    document.getElementById('detailStatus').value = transaction.status || 'missing';
    document.getElementById('detailCategory').value = transaction.category || '';
    document.getElementById('detailNotes').value = transaction.notes || '';

    await loadReceipts(transaction.id);
}

async function loadReceipts(transactionId) {
    const receipts = await window.api.getReceipts(transactionId);

    const list = document.getElementById('receiptList');
    list.innerHTML = '';

    if (receipts.length === 0) {
        const li = document.createElement('li');
        li.className = 'muted';
        li.textContent = 'Aucun justificatif attaché.';
        list.appendChild(li);
        return;
    }

    receipts.forEach(receipt => {
        const li = document.createElement('li');
        const button = document.createElement('button');

        button.textContent = 'Ouvrir';
        button.addEventListener('click', async () => {
            await window.api.openFile(receipt.filepath);
        });

        li.textContent = `${receipt.filename} — ${receipt.added_at} `;
        li.appendChild(button);
        list.appendChild(li);
    });
}

document.getElementById('newCompany').addEventListener('click', async () => {
    const input = document.getElementById('companyName');
    const name = input.value.trim();

    if (!name) return;

    await window.api.addCompany(name);

    input.value = '';
    await loadCompanies();
});

document.getElementById('newBankAccount').addEventListener('click', async () => {
    if (!selectedCompany) return;

    const bankNameInput = document.getElementById('bankName');
    const accountNameInput = document.getElementById('accountName');
    const ibanInput = document.getElementById('iban');

    const bankName = bankNameInput.value.trim();
    const accountName = accountNameInput.value.trim();
    const iban = ibanInput.value.trim();

    if (!bankName) return;

    await window.api.addBankAccount({
        companyId: selectedCompany.id,
        bankName,
        accountName,
        iban
    });

    bankNameInput.value = '';
    accountNameInput.value = '';
    ibanInput.value = '';

    await loadBankAccounts();
});

document.getElementById('importStatement').addEventListener('click', async () => {
    if (!selectedBankAccount) return;

    const pdf = await window.api.selectPdf();
    if (!pdf) return;

    const result = await window.api.addStatement({
        bankAccountId: selectedBankAccount.id,
        filename: pdf.filename,
        filepath: pdf.filepath
    });

    if (!result.imported) {
        alert(result.message);
    } else {
        alert(`${result.transactionsCount} opération(s) détectée(s)`);
    }

    await refreshAccountView();
});

document.getElementById('saveTransactionDetails').addEventListener('click', async () => {
    if (!selectedTransaction) return;

    const status = document.getElementById('detailStatus').value;
    const category = document.getElementById('detailCategory').value.trim();
    const notes = document.getElementById('detailNotes').value.trim();

    await window.api.updateTransactionStatus({
        transactionId: selectedTransaction.id,
        status
    });

    await window.api.updateTransactionDetails({
        transactionId: selectedTransaction.id,
        category,
        notes
    });

    await showTransactionDetail(selectedTransaction.id);
    await refreshAccountView();
});

document.getElementById('addReceipt').addEventListener('click', async () => {
    if (!selectedTransaction) return;

    const receipt = await window.api.selectReceipt();
    if (!receipt) return;

    await window.api.addReceipt({
        transactionId: selectedTransaction.id,
        filename: receipt.filename,
        filepath: receipt.filepath
    });

    await showTransactionDetail(selectedTransaction.id);
    await refreshAccountView();
});

loadCompanies();
