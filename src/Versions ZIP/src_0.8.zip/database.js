const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, '..', 'ThetaCompta.db');
const db = new Database(dbPath);

db.exec(`
CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bank_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    company_id INTEGER NOT NULL,
    bank_name TEXT NOT NULL,
    account_name TEXT,
    iban TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(company_id) REFERENCES companies(id)
);

CREATE TABLE IF NOT EXISTS statements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bank_account_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    filepath TEXT NOT NULL,
    imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id)
);

CREATE TABLE IF NOT EXISTS bank_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bank_account_id INTEGER NOT NULL,
    date_operation TEXT,
    label TEXT,
    amount REAL,
    type TEXT,
    pdf_source TEXT,
    status TEXT DEFAULT 'missing',
    category TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(bank_account_id) REFERENCES bank_accounts(id)
);

CREATE TABLE IF NOT EXISTS receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transaction_id INTEGER NOT NULL,
    filename TEXT NOT NULL,
    filepath TEXT NOT NULL,
    added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(transaction_id) REFERENCES bank_transactions(id)
);
`);

function ensureColumn(tableName, columnName, definition) {
    const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
    const exists = columns.some(column => column.name === columnName);

    if (!exists) {
        db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
    }
}

ensureColumn('bank_transactions', 'status', "TEXT DEFAULT 'missing'");
ensureColumn('bank_transactions', 'category', 'TEXT');
ensureColumn('bank_transactions', 'notes', 'TEXT');

function createCompany(name) {
    return db.prepare(`
        INSERT INTO companies(name)
        VALUES(?)
    `).run(name);
}

function getCompanies() {
    return db.prepare(`
        SELECT *
        FROM companies
        ORDER BY name
    `).all();
}

function createBankAccount(companyId, bankName, accountName, iban) {
    return db.prepare(`
        INSERT INTO bank_accounts(
            company_id,
            bank_name,
            account_name,
            iban
        )
        VALUES(?, ?, ?, ?)
    `).run(companyId, bankName, accountName, iban);
}

function getBankAccounts(companyId) {
    return db.prepare(`
        SELECT *
        FROM bank_accounts
        WHERE company_id = ?
        ORDER BY bank_name
    `).all(companyId);
}

function createStatement(bankAccountId, filename, filepath) {
    return db.prepare(`
        INSERT INTO statements(
            bank_account_id,
            filename,
            filepath
        )
        VALUES(?, ?, ?)
    `).run(bankAccountId, filename, filepath);
}

function getStatements(bankAccountId) {
    return db.prepare(`
        SELECT *
        FROM statements
        WHERE bank_account_id = ?
        ORDER BY imported_at DESC
    `).all(bankAccountId);
}

function statementExists(bankAccountId, filepath) {
    return db.prepare(`
        SELECT *
        FROM statements
        WHERE bank_account_id = ?
        AND filepath = ?
    `).get(bankAccountId, filepath);
}

function createTransaction(
    bankAccountId,
    dateOperation,
    label,
    amount,
    type,
    pdfSource
) {
    return db.prepare(`
        INSERT INTO bank_transactions(
            bank_account_id,
            date_operation,
            label,
            amount,
            type,
            pdf_source,
            status
        )
        VALUES (?, ?, ?, ?, ?, ?, 'missing')
    `).run(
        bankAccountId,
        dateOperation,
        label,
        amount,
        type,
        pdfSource
    );
}

function getTransactions(bankAccountId) {
    return db.prepare(`
        SELECT
            t.*,
            COUNT(r.id) AS receipts_count
        FROM bank_transactions t
        LEFT JOIN receipts r ON r.transaction_id = t.id
        WHERE t.bank_account_id = ?
        GROUP BY t.id
        ORDER BY t.id DESC
    `).all(bankAccountId);
}

function getTransaction(transactionId) {
    return db.prepare(`
        SELECT
            t.*,
            COUNT(r.id) AS receipts_count
        FROM bank_transactions t
        LEFT JOIN receipts r ON r.transaction_id = t.id
        WHERE t.id = ?
        GROUP BY t.id
    `).get(transactionId);
}

function updateTransactionStatus(transactionId, status) {
    return db.prepare(`
        UPDATE bank_transactions
        SET status = ?
        WHERE id = ?
    `).run(status, transactionId);
}

function updateTransactionDetails(transactionId, category, notes) {
    return db.prepare(`
        UPDATE bank_transactions
        SET category = ?, notes = ?
        WHERE id = ?
    `).run(category, notes, transactionId);
}

function createReceipt(transactionId, filename, filepath) {
    const result = db.prepare(`
        INSERT INTO receipts(
            transaction_id,
            filename,
            filepath
        )
        VALUES(?, ?, ?)
    `).run(transactionId, filename, filepath);

    db.prepare(`
        UPDATE bank_transactions
        SET status = 'attached'
        WHERE id = ?
        AND status = 'missing'
    `).run(transactionId);

    return result;
}

function getReceipts(transactionId) {
    return db.prepare(`
        SELECT *
        FROM receipts
        WHERE transaction_id = ?
        ORDER BY added_at DESC
    `).all(transactionId);
}

function getTransactionSummary(bankAccountId) {
    const total = db.prepare(`
        SELECT COUNT(*) AS count
        FROM bank_transactions
        WHERE bank_account_id = ?
    `).get(bankAccountId).count;

    const missing = db.prepare(`
        SELECT COUNT(*) AS count
        FROM bank_transactions
        WHERE bank_account_id = ?
        AND status = 'missing'
    `).get(bankAccountId).count;

    const attached = db.prepare(`
        SELECT COUNT(*) AS count
        FROM bank_transactions
        WHERE bank_account_id = ?
        AND status IN ('attached', 'verified')
    `).get(bankAccountId).count;

    const debit = db.prepare(`
        SELECT COALESCE(SUM(amount), 0) AS total
        FROM bank_transactions
        WHERE bank_account_id = ?
        AND amount < 0
    `).get(bankAccountId).total;

    const credit = db.prepare(`
        SELECT COALESCE(SUM(amount), 0) AS total
        FROM bank_transactions
        WHERE bank_account_id = ?
        AND amount > 0
    `).get(bankAccountId).total;

    return {
        total,
        missing,
        attached,
        debit,
        credit
    };
}

module.exports = {
    db,

    createCompany,
    getCompanies,

    createBankAccount,
    getBankAccounts,

    createStatement,
    getStatements,
    statementExists,

    createTransaction,
    getTransactions,
    getTransaction,
    updateTransactionStatus,
    updateTransactionDetails,
    getTransactionSummary,

    createReceipt,
    getReceipts
};
