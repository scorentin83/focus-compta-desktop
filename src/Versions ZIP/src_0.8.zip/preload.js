const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {

    addCompany: (name) =>
        ipcRenderer.invoke('add-company', name),

    getCompanies: () =>
        ipcRenderer.invoke('get-companies'),

    addBankAccount: (data) =>
        ipcRenderer.invoke('add-bank-account', data),

    getBankAccounts: (companyId) =>
        ipcRenderer.invoke('get-bank-accounts', companyId),

    selectPdf: () =>
        ipcRenderer.invoke('select-pdf'),

    addStatement: (data) =>
        ipcRenderer.invoke('add-statement', data),

    getStatements: (bankAccountId) =>
        ipcRenderer.invoke('get-statements', bankAccountId),

    getTransactions: (bankAccountId) =>
        ipcRenderer.invoke('get-transactions', bankAccountId),

    getTransaction: (transactionId) =>
        ipcRenderer.invoke('get-transaction', transactionId),

    updateTransactionStatus: (data) =>
        ipcRenderer.invoke('update-transaction-status', data),

    updateTransactionDetails: (data) =>
        ipcRenderer.invoke('update-transaction-details', data),

    getTransactionSummary: (bankAccountId) =>
        ipcRenderer.invoke('get-transaction-summary', bankAccountId),

    selectReceipt: () =>
        ipcRenderer.invoke('select-receipt'),

    addReceipt: (data) =>
        ipcRenderer.invoke('add-receipt', data),

    getReceipts: (transactionId) =>
        ipcRenderer.invoke('get-receipts', transactionId),

    openFile: (filepath) =>
        ipcRenderer.invoke('open-file', filepath)

});
