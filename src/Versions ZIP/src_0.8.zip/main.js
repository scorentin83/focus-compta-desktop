const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const pdfParseModule = require('pdf-parse');

const PDFParse = pdfParseModule.PDFParse;

const {
    createCompany,
    getCompanies,
    createBankAccount,
    getBankAccounts,
    createStatement,
    getStatements,
    statementExists,
    createTransaction,
    getTransactions,
    getTransaction,
    updateTransactionStatus,
    updateTransactionDetails,
    getTransactionSummary,
    createReceipt,
    getReceipts
} = require('./database');

function createWindow() {
    const win = new BrowserWindow({
        width: 1600,
        height: 950,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        }
    });

    win.loadFile(path.join(__dirname, 'index.html'));
}

function parseFrenchAmount(value) {
    return Number(
        value
            .replace(/\s/g, '')
            .replace(',', '.')
    );
}

function normalizeDate(value) {
    return value.replace('.', '/');
}

function parseCreditAgricoleTransactions(text, bankAccountId, filename) {
    const lines = text
        .split(/\r?\n/)
        .map(line => line.trim())
        .filter(Boolean);

    const transactions = [];
    const operationRegex = /^(\d{2}\.\d{2})\s+(\d{2}\.\d{2})\s+(.+?)\s+(\d[\d\s]*,\d{2})\s*¨?$/;

    for (const line of lines) {
        if (
            line.includes('Ancien solde') ||
            line.includes('Nouveau solde') ||
            line.includes('Total des opérations') ||
            line.includes('Date opé') ||
            line.includes('Date valeur')
        ) {
            continue;
        }

        const match = line.match(operationRegex);
        if (!match) continue;

        const dateOperation = normalizeDate(match[1]);
        const label = match[3].trim();
        console.log('LIGNE =', line);
console.log('AMOUNT RAW =', amountRaw);
        const amount = parseFrenchAmount(match[4]);

        const lowerLabel = label.toLowerCase();
        const isDebit =
            lowerLabel.startsWith('prlv') ||
            lowerLabel.includes(' vers ') ||
            lowerLabel.includes('vir inst vers') ||
            lowerLabel.includes('cotis') ||
            lowerLabel.includes('frais') ||
            lowerLabel.includes('facture crédit agricole');

        const signedAmount = isDebit ? -amount : amount;
        const type = isDebit ? 'debit' : 'credit';

        const transaction = {
            bankAccountId,
            dateOperation,
            label,
            amount: signedAmount,
            type,
            pdfSource: filename
        };

        createTransaction(
            transaction.bankAccountId,
            transaction.dateOperation,
            transaction.label,
            transaction.amount,
            transaction.type,
            transaction.pdfSource
        );

        transactions.push(transaction);
    }

    return transactions;
}

app.whenReady().then(() => {
    createWindow();
});

ipcMain.handle('add-company', async (event, name) => {
    createCompany(name);
    return true;
});

ipcMain.handle('get-companies', async () => {
    return getCompanies();
});

ipcMain.handle('add-bank-account', async (event, data) => {
    createBankAccount(
        data.companyId,
        data.bankName,
        data.accountName,
        data.iban
    );

    return true;
});

ipcMain.handle('get-bank-accounts', async (event, companyId) => {
    return getBankAccounts(companyId);
});

ipcMain.handle('select-pdf', async () => {
    const result = await dialog.showOpenDialog({
        title: 'Importer un relevé bancaire PDF',
        filters: [
            { name: 'PDF', extensions: ['pdf'] }
        ],
        properties: ['openFile']
    });

    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }

    const filepath = result.filePaths[0];
    const filename = path.basename(filepath);

    return {
        filename,
        filepath
    };
});

ipcMain.handle('add-statement', async (event, data) => {
    const existing = statementExists(
        data.bankAccountId,
        data.filepath
    );

    if (existing) {
        return {
            imported: false,
            message: 'PDF déjà importé',
            transactionsCount: 0
        };
    }

    createStatement(
        data.bankAccountId,
        data.filename,
        data.filepath
    );

    const buffer = fs.readFileSync(data.filepath);

    const parser = new PDFParse({
        data: buffer
    });

    const parsed = await parser.getText();

    const transactions = parseCreditAgricoleTransactions(
        parsed.text,
        data.bankAccountId,
        data.filename
    );

    return {
        imported: true,
        transactionsCount: transactions.length
    };
});

ipcMain.handle('get-statements', async (event, bankAccountId) => {
    return getStatements(bankAccountId);
});

ipcMain.handle('get-transactions', async (event, bankAccountId) => {
    return getTransactions(bankAccountId);
});

ipcMain.handle('get-transaction', async (event, transactionId) => {
    return getTransaction(transactionId);
});

ipcMain.handle('update-transaction-status', async (event, data) => {
    updateTransactionStatus(data.transactionId, data.status);
    return true;
});

ipcMain.handle('update-transaction-details', async (event, data) => {
    updateTransactionDetails(data.transactionId, data.category, data.notes);
    return true;
});

ipcMain.handle('get-transaction-summary', async (event, bankAccountId) => {
    return getTransactionSummary(bankAccountId);
});

ipcMain.handle('select-receipt', async () => {
    const result = await dialog.showOpenDialog({
        title: 'Ajouter un justificatif',
        filters: [
            { name: 'Documents', extensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'] }
        ],
        properties: ['openFile']
    });

    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }

    const filepath = result.filePaths[0];
    const filename = path.basename(filepath);

    return {
        filename,
        filepath
    };
});

ipcMain.handle('add-receipt', async (event, data) => {
    createReceipt(data.transactionId, data.filename, data.filepath);
    return true;
});

ipcMain.handle('get-receipts', async (event, transactionId) => {
    return getReceipts(transactionId);
});

ipcMain.handle('open-file', async (event, filepath) => {
    await shell.openPath(filepath);
    return true;
});
